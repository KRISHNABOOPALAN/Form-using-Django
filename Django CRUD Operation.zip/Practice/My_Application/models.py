from django.db import models

class RegisterForm(models.Model):
    Name=models.CharField(max_length=100)
    Age=models.IntegerField()
    Designation=models.CharField(max_length=100)
    Salary=models.BigIntegerField()
    Email=models.EmailField()
    Mobile=models.BigIntegerField()

# Create your models here.
